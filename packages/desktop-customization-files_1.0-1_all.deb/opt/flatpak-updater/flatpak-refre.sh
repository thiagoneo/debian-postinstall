#!/bin/bash

flatpak update | cat > /tmp/flatpak-upgradable

grep 'Prosseguir com essas alterações para a instalação da sistema?' /tmp/flatpak-upgradable

if [[ $? != 1 ]]; then
    ACTION=`dunstify 'Atualizações de Flatpaks disponíveis' \
           'Clique no botão para atualizar.' -u critical \
           -i software-update-available-symbolic \
           --action="updateAction,Atualizar"`
    if [[ $ACTION == "updateAction" ]]; then
        xfce4-terminal -e "/opt/flatpak-updater/flatpak-upgrade"
    fi
else
    echo "Todos os aplicativos estão atualizados."
fi

rm /tmp/flatpak-upgradable
